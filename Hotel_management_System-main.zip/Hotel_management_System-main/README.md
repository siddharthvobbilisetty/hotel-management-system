
# Hotel_management_System
<h1>My class 12 IP Project created in JAVA language using Netbeans 8.2 and Mysql 

<h2>Aim!</h2>

The solo purpose of the software is to meet the intended users’ need. As it reflects from the statement SOFTWARE DEVELOPMENT IS THE TRANSLATION OF A USERS’ NEED. If all the requirements of users are served by computerized solution, the user is satisfied enough thus the software should be designed effectively so as to meet its objective of user satisfaction. The designing equally applies to database design and development. The most important things to keep in mind throughout the design process are integrity of the data so that in future the data should be retrieved. To avoid these bugs a systematic approach is followed. This involves lot of steps and phases. This systematic approach of developing database is called DATABSE DEVELOPMENT LIFE CYCLE or DDLC. This is similar to SYSTEM DEVELOPMENT LIFE CYCLE or SDLC.

<h2>Scope</h2>
Today, be it a company, institution or a non-governmental organization, for the smooth running of them all, we need a backup data, so that vital information can be stored, preserved, retrieved and used as per the requirements.
Companies employ what they call computer operators who store all the necessary information regarding the company. What is much needed is a proper interface which may enable us to handle such systems efficiently.
This project entitled “Hotel Management Software” has been developed with an aim to help such a Company/Hotel to easily manage data concerning it.

<h2>MySql</h2>- 
Here MYSQL is the back end used. It the most popular Open Source SQL database management system, is developed, distributed, and supported by Oracle Corporation. MySQL is (as of December 2015) the world's second most widely used open-source relational database management system (RDBMS).It is named after co-founder Michael Widenius's daughter. The SQL phrase stands for Structured Query Language.
The MySQL development project has made its source code available under the terms of the GNU General Public License, as well as under a variety of proprietary agreements. MySQL was owned and sponsored by a single for-profit firm, the Swedish company MySQL AB, now owned by Oracle Corporation
 
 
 <h1> LAYOUT DIAGRAM </h1>

  ![hotel](https://user-images.githubusercontent.com/60483148/135767570-084981c7-caa8-4e74-9316-1f5c5e0256b2.png)
